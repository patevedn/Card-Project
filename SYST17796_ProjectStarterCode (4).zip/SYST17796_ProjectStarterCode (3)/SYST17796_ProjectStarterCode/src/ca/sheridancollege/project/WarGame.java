/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca.sheridancollege.project;

/**
 *
 * @author chira
 */

import java.util.ArrayList;
import java.util.Scanner;

public class WarGame extends Game {
    private GroupOfCards deck;

    public WarGame(String name) {
        super(name);
        deck = new GroupOfCards(52); // Initialize a deck with 52 cards
        initializeDeck(); // Initialize the deck with cards
    }

    private void initializeDeck() {
        for (int rank = 2; rank <= 14; rank++) {
            deck.getCards().add(new WarCard(rank));
        }
        deck.shuffle();
    }

    @Override
    protected void createPlayers() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter name for Player 1: ");
        String playerName1 = scanner.nextLine();
        WarPlayer player1 = new WarPlayer(playerName1, new GroupOfCards(0));

        System.out.print("Enter name for Player 2: ");
        String playerName2 = scanner.nextLine();
        WarPlayer player2 = new WarPlayer(playerName2, new GroupOfCards(0));

        getPlayers().add(player1);
        getPlayers().add(player2);
    }

    @Override
    protected void distributeCards() {
        WarPlayer player1 = (WarPlayer) getPlayers().get(0);
        WarPlayer player2 = (WarPlayer) getPlayers().get(1);

        for (int i = 0; i < deck.getCards().size(); i++) {
            if (i % 2 == 0) {
                player1.getDeck().getCards().add(deck.getCards().get(i));
            } else {
                player2.getDeck().getCards().add(deck.getCards().get(i));
            }
        }
    }

   @Override
protected void playRound() {
    Scanner scanner = new Scanner(System.in);
    WarPlayer player1 = (WarPlayer) getPlayers().get(0);
    WarPlayer player2 = (WarPlayer) getPlayers().get(1);

    System.out.println(player1.getName() + ", press Enter to draw a card...");
    scanner.nextLine();

    Card card1 = player1.getCard();
    System.out.println(player1.getName() + " drew: " + card1);

    // Computer (player 2) automatically draws a card
    Card card2 = player2.getCard();
    System.out.println(player2.getName() + " drew: " + card2);

    if (((WarCard) card1).getRank() > ((WarCard) card2).getRank()) {
        player1.getDeck().getCards().add(card1);
        player1.getDeck().getCards().add(card2);
        System.out.println(player1.getName() + " wins the round!");
    } else if (((WarCard) card2).getRank() > ((WarCard) card1).getRank()) {
        player2.getDeck().getCards().add(card2);
        player2.getDeck().getCards().add(card1);
        System.out.println(player2.getName() + " wins the round!");
    } else {
        System.out.println("It's a tie! Prepare for war!");
        // TODO: Implement war logic
    }

    System.out.println(player1.getName() + "'s deck size: " + player1.getDeck().getSize());
    System.out.println(player2.getName() + "'s deck size: " + player2.getDeck().getSize());

    System.out.println("Press Enter to continue to the next round or type 'quit' to end the game...");
    String userInput = scanner.nextLine();
    if ("quit".equalsIgnoreCase(userInput)) {
        setPlayers(new ArrayList<>());
        return;
    }
}

   @Override
protected boolean isGameOver() {
    if (getPlayers().isEmpty()) {
        return true; // No players left, the game is over
    }
    WarPlayer player1 = (WarPlayer) getPlayers().get(0);
    WarPlayer player2 = (WarPlayer) getPlayers().get(1);
    return player1.getDeck().isEmpty() || player2.getDeck().isEmpty();
}


    @Override
public void declareWinner() {
    if (getPlayers().isEmpty()) {
        System.out.println("No players left. The game has ended.");
    } else {
        WarPlayer player1 = (WarPlayer) getPlayers().get(0);
        WarPlayer player2 = (WarPlayer) getPlayers().get(1);

        int player1DeckSize = player1.getDeck().getSize();
        int player2DeckSize = player2.getDeck().getSize();

        if (player1DeckSize > player2DeckSize) {
            System.out.println(player1.getName() + " wins the game!");
        } else if (player2DeckSize > player1DeckSize) {
            System.out.println(player2.getName() + " wins the game!");
        } else {
            System.out.println("It's a tie! The game has ended in a draw.");
        }
    }
}


    public static void main(String[] args) {
        WarGame warGame = new WarGame("War Game");
        warGame.play();
        warGame.declareWinner();
    }
}