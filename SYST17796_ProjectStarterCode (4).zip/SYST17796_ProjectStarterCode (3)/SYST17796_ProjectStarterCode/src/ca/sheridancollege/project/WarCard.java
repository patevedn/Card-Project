/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca.sheridancollege.project;

/**
 *
 * @author chira
 */

public class WarCard extends Card {
    private int rank;

    public WarCard(int rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return Integer.toString(rank);
    }

    public int getRank() {
        return rank;
    }
}