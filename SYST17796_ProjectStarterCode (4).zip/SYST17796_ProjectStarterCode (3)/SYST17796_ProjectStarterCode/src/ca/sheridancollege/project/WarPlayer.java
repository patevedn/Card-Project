/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca.sheridancollege.project;



/**
 *
 * @author chira
 */
public class WarPlayer extends Player {
    private GroupOfCards deck;

    public WarPlayer(String name, GroupOfCards deck) {
        super(name);
        this.deck = deck;
    }

    public GroupOfCards getDeck() {
        return deck;
    }

    @Override
    public Card getCard() {
        return deck.getCards().remove(0);
    }
}